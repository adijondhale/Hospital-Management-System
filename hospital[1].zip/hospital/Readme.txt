Login Details:

Login Details for admin : admin/Test@12345
Login Details for Patient: johndoe12@test.com/Test@123
Login Details for Doctor: anujk123@test.com/Test@123

